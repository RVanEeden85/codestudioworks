# CodeStudioWorks logo pack

This pack is based on the approved CSW monogram concept. The silhouette and lime terminal were traced from the selected source, then converted into deterministic light, reverse, monochrome, website, email, and icon exports.

## Recommended files

- Website or document, light background: `svg/codestudioworks-logo-stacked.svg`
- Dark background: `svg/codestudioworks-logo-stacked-reverse.svg`
- Email signature: `png/codestudioworks-logo-email-600.png` at 300 CSS pixels wide
- Avatar or social profile: `png/codestudioworks-csw-icon-1024.png`
- Favicon: `png/codestudioworks-csw-icon-32.png`
- One-color production: `svg/codestudioworks-logo-stacked-monochrome.svg`

## Usage

Keep clear space around the logo equal to roughly the height of the small CodeStudioWorks wordmark. Do not stretch, rotate, add effects, or change the relationship between the CSW monogram and the lime terminal.

## Colors

- Forest: `#0c1f1d`
- Lime: `#d7f45d`
- Warm white: `#fffdf7`
